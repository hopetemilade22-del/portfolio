# Hope Adesina — Portfolio

## How to deploy to GitHub Pages

1. Upload every file in this folder to your `portfolio` repo (replace what's there now — same repo, same URL: `hopetemilade22-del.github.io/portfolio`). Everything sits at one level — no folders to worry about, which matters for uploading from a phone.
2. In the repo's **Settings → Pages**, make sure the source is set to your default branch (usually `main`), root folder.
3. Give it a minute — your site updates at the same address.

No build step, no dependencies to install. It's plain HTML, CSS and JavaScript.

## How to add a new project (Crocs, Kivo, Brochure, Logo work, etc.)

You only ever need to touch **one file**: `projects-data.js`.

1. Save your new image(s) with a short, unique filename (e.g. `newproject-1.jpg`) — no spaces.
2. Open `projects-data.js`.
3. Copy one of the existing project blocks, paste it where you want it to appear in the list, and fill in your details. Delete any line you don't have information for — don't write "N/A".
4. Point `cover` (and `gallery`, if you have more than one image) at your new filename — just the filename, e.g. `"newproject-1.jpg"`.
5. Save the file, then upload the new image file(s) and the edited `projects-data.js` to your GitHub repo the same way as before — everything goes in at the same single level, no folders.

Full field-by-field instructions are written as comments at the top of that file.

## Files in this folder

```
index.html          → the page itself (structure/copy — rarely needs editing)
style.css            → all visual styling
projects-data.js     → ALL project content lives here — this is what you'll edit
main.js              → renders the work grid, handles nav + filters (rarely needs editing)
*.jpg                → your photo, Sips & Bites assets, and every project image
```

## What's included right now

- Hero, About, Services, Selected Work, Experience, Skills, Contact — matching your existing site's structure.
- Crocs, Kivo, IKEA brochure and the KPMG/Deloitte/PwC set — labelled as brand-identity design practice from your TJD mentorship, not real client work.
- Sips & Bites, the M-KOPA SEO audit, the email campaign, Brand Identity & Fliers, and the short-form content portfolio.
- A working filter on Selected Work (All / Brand / Content / SEO / Email / Design), and each project card expands in place to show the brief, approach, tools and result.

## Still to add (whenever you're ready)

- Any more graphics you mentioned having
- Real images for M-KOPA, the email campaign, and the content portfolio (they're text-only right now)

Same process as before: images go in `assets/projects/`, details go in `js/projects-data.js`.
